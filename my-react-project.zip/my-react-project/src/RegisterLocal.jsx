import { useState } from 'react';
import './RegisterLocal.css';
import Calendar from './Calendar.jsx';

function RegisterLocal() {
    const [name, setName] = useState('');
    const [seats, setSeats] = useState('');
    const [openingHours, setOpeningHours] = useState('');
    const [closingHours, setClosingHours] = useState('');
    const [openingDays, setOpeningDays] = useState({
        Monday: false,
        Tuesday: false,
        Wednesday: false,
        Thursday: false,
        Friday: false,
        Saturday: false,
        Sunday: false
    });
    const [showCalendar, setShowCalendar] = useState(false);

    const handleDayChange = (day) => {
        setOpeningDays({ ...openingDays, [day]: !openingDays[day] });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
    };

    const navigateToCalendar = () => {
        setShowCalendar(true); 
    };

    return (
        <div className="form-container">
            {showCalendar ? <Calendar openingDays={openingDays} /> : (
                <form onSubmit={handleSubmit}>
                    <label htmlFor="name">Name of Local:</label>
                    <input type="text" id="name" className="form-input" value={name} onChange={(e) => setName(e.target.value)} />
                    <label htmlFor="seats">Amount of Seats:</label>
                    <input type="text" id="seats" className="form-input" value={seats} onChange={(e) => setSeats(e.target.value)} />
                    <label htmlFor="openingHours">Opening Hours:</label>
                    <input type="text" id="openingHours" className="form-input" value={openingHours} onChange={(e) => setOpeningHours(e.target.value)} />
                    <label htmlFor="closingHours">Closing Hours:</label>
                    <input type="text" id="closingHours" className="form-input" value={closingHours} onChange={(e) => setClosingHours(e.target.value)} />
                    <div>
                        <label className="form-label">Opening Days:</label><br />
                        {Object.keys(openingDays).map((day, index) => (
                            <div key={index} className="form-checkbox">
                                <input type="checkbox" id={day} className="form-checkbox-input" checked={openingDays[day]} onChange={() => handleDayChange(day)} />
                                <label htmlFor={day} className="form-checkbox-label">{day}</label>
                            </div>
                        ))}
                    </div>
                    <button type="button" className="form-submit" onClick={navigateToCalendar}>Register</button>
                </form>
            )}
        </div>
    );
}

export default RegisterLocal;
