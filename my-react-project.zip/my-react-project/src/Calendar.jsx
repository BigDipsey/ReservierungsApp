import PropTypes from 'prop-types';
import './Calendar.css';

function Calendar({ openingDays }) {
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  const numDaysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const daysInMonth = Array.from({ length: numDaysInMonth }, (_, index) => index + 1);
  const emptySlots = Array.from({ length: firstDayOfMonth }, (_, index) => index);

  const isDayBooked = (day) => {
    const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date(currentYear, currentMonth, day).getDay()];
    return !openingDays[dayName];
  };

  const handleDayClick = (day) => {
    if (isDayBooked(day)) {
      alert('Geschlossen');
    } else {
      const guestCount = prompt('Anzahl der Gäste eingeben:');
      if (guestCount !== null) {
        alert(`Sie haben ${guestCount} Gäste für den ${day}.${currentMonth + 1}.${currentYear} reserviert.`);
      }
    }
  };

  return (
    <div className="calendar">
      <h2>{today.toLocaleString('default', { month: 'long' })} {currentYear}</h2>
      <div className="weekdays">
        <div>Sun</div>
        <div>Mon</div>
        <div>Tue</div>
        <div>Wed</div>
        <div>Thu</div>
        <div>Fri</div>
        <div>Sat</div>
      </div>
      <div className="days">
        {emptySlots.map((slot, index) => (
          <div key={index}></div>
        ))}
        {daysInMonth.map((day) => (
          <div key={day} onClick={() => handleDayClick(day)} className={isDayBooked(day) ? 'booked' : ''}>{day}</div>
        ))}
      </div>
    </div>
  );
}

Calendar.propTypes = {
  openingDays: PropTypes.object.isRequired,
};

export default Calendar;
