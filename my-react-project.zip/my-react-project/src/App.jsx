import RegisterLocal from './RegisterLocal';

const App = () => {
 
  return (
    <div>
      <h1>Local Opening Days</h1>
      <RegisterLocal/>
    </div>
  );
};

export default App;
